﻿namespace Bank
{
    interface IWithDrawable
    {
        void WithDrawMomey(decimal amout);
    }
}
