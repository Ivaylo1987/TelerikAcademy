﻿namespace MatrixWalk
{
    public interface IDirection
    {
        int X { get; }

        int Y { get; }
    }
}
